public interface C {

    void aa(); # пришлось добавить т к одинаковы

    String kk();
}
