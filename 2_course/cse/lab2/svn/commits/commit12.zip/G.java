public class G extends null {

    float ff();

    Object pp();

    public double ad() {
        return 12.12;
    }

    public int ae() {
        return 9;
    }
}
