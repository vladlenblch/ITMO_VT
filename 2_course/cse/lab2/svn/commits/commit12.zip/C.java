public class C extends null {

    void aa();

    String kk();

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }
}
