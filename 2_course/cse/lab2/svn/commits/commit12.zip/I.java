public class I extends null implements G, C {

    private int c = 42;

    private byte d = 1;

    public double ad() {
        return 9.11;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public float ff() {
        return 0;
    }

    public Object pp() {
        return this;
    }

    public void aa() {
        System.out.println("void aa");
    }

    public String kk() {
        return "No";
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public byte oo() {
        return 2;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public long dd() {
        return 99999;
    }

    public void ab() {
        System.out.println("\n");
    }

    public double ee() {
        return 0.000001;
    }

    public int cc() {
        return 42;
    }

    public java.lang.Class qq() {
        return getClass();
    }
}
