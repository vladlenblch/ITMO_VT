public class G extends null {

    float ff();

    Object pp();

    public double ad() {
        return 12.12;
    }

    public int ae() {
        return 9;
    }

    public String kk() {
        return "No";
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }
}
