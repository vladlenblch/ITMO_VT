public class H extends null implements C {

    private byte j = 1;

    private String f = "init";

    public Object rr() {
        return null;
    }

    public int af() {
        return -1;
    }

    public void aa() {
        return;
    }

    public String kk() {
        return "No";
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public double ee() {
        return 500.100;
    }

    public double ad() {
        return 9.11;
    }

    public int cc() {
        return 13;
    }

    public long dd() {
        return 100500;
    }

    public Object pp() {
        return this;
    }

    public void bb() {
        System.out.println(42);
    }

    public long ac() {
        return 222;
    }
}
