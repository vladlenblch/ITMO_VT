public class H extends null implements C {

    private byte j = 1;

    private String f = "init";

    public Object rr() {
        return null;
    }

    public int af() {
        return -1;
    }

    public void aa() {
        return;
    }

    public String kk() {
        return "No";
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public double ee() {
        return 100.500;
    }

    public float ff() {
        return 0;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }
}
