public class G extends null {

    float ff();

    Object pp();

    public java.util.Random mm() {
        return new java.util.Random();
    }
}
