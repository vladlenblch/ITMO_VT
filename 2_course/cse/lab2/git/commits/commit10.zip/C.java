public class C extends null {

    void aa();

    String kk();

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }
}
