public class G extends null {

    float ff();

    Object pp();
}
