public class C extends null {

    void aa();

    String kk();
}
